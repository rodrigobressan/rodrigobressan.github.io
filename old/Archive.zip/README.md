Under development :-)

This is a GitHub page for my thoughts about software development.

It uses the GitHub pages hosting with the Jekyll. Theme 'Leonids' created by user renyuanz (https://github.com/renyuanz/).
